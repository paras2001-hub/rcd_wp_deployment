# RCD CRM Plugin

## Description
A comprehensive CRM plugin for managing Associates and Customers in the real estate sector.

## Installation
1. Upload the plugin to your WordPress plugins directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Configure settings under the RCD CRM menu in the admin dashboard.

## Features
- User registration and role management
- Lead management system
- Commission tracking
- Referral system
